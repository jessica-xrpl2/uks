<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="themes/assets/ico/favicon.ico">
    <title>Bootstrappage.com free templates</title>

    <!-- Bootstrap core CSS -->
    <link href="{asset('front-temp/themes/dist/css/bootstrap.min.css')}" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="themes/assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('front-temp/themes/assets/css/carousel.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
</head>
<!-- NAVBAR
================================================== -->

<body>
    <div class="navbar-wrapper">
        <div class="container">

            <div class="navbar navbar-inverse navbar-static-top" role="navigation">
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="index.html">Bootstrap Restaurant</a>
                    </div>
                    <div class="navbar-collapse collapse">
                        <ul class="nav navbar-nav">
                            <li class="active"><a href="index.html">Home</a></li>
                            <li><a href="about.html">About Us</a></li>
                            <li><a href="contact.html">Contact</a></li>
                            <li><a href="#tablebooking">Table Booking</a></li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Indina <b class="caret"></b></a>
                                <ul class="dropdown-menu">
                                    <li><a href="#">DRINKS</a></li>
                                    <li><a href="#">STARTERS</a></li>
                                    <li><a href="#">TANDOORI - CLAY OVEN - DISHES</a></li>
                                    <li class="divider"></li>
                                    <li class="dropdown-header">SEAFOOD MAIN COURSES</li>
                                    <li><a href="#">CHICKEN MAIN COURSES</a></li>
                                    <li><a href="#">LAMB MAIN COURSES</a></li>
                                    <li><a href="#">RICE/BREDS</a></li>
                                    <li><a href="#">ACCOMPANIMENTS</a></li>
                                </ul>
                            </li>

                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Italian <b class="caret"></b></a>
                                <ul class="dropdown-menu">
                                    <li><a href="#">DRINKS</a></li>
                                    <li><a href="#">STARTERS</a></li>
                                    <li><a href="#">TANDOORI - CLAY OVEN - DISHES</a></li>
                                    <li class="divider"></li>
                                    <li class="dropdown-header">SEAFOOD MAIN COURSES</li>
                                    <li><a href="#">CHICKEN MAIN COURSES</a></li>
                                    <li><a href="#">LAMB MAIN COURSES</a></li>
                                    <li><a href="#">RICE/BREDS</a></li>
                                    <li><a href="#">ACCOMPANIMENTS</a></li>
                                </ul>
                            </li>

                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Chines <b class="caret"></b></a>
                                <ul class="dropdown-menu">
                                    <li><a href="#">DRINKS</a></li>
                                    <li><a href="#">STARTERS</a></li>
                                    <li><a href="#">TANDOORI - CLAY OVEN - DISHES</a></li>
                                    <li class="divider"></li>
                                    <li class="dropdown-header">SEAFOOD MAIN COURSES</li>
                                    <li><a href="#">CHICKEN MAIN COURSES</a></li>
                                    <li><a href="#">LAMB MAIN COURSES</a></li>
                                    <li><a href="#">RICE/BREDS</a></li>
                                    <li><a href="#">ACCOMPANIMENTS</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

        </div>
    </div><?php /**PATH C:\xampp\htdocs\belajar2\resources\views/front/layouts/navbar.blade.php ENDPATH**/ ?>