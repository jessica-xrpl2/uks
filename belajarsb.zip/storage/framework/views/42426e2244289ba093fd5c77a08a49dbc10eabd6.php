<!-- food section -->

<section class="food_section layout_padding-bottom">
    <div class="container">
        <div class="heading_container heading_center mt-4">
            <h2>
                Nang Seng
            </h2>
        </div>
    </div>
</section>

<!-- end food section --><?php /**PATH C:\xampp\htdocs\belajar2\resources\views/front/layouts/content.blade.php ENDPATH**/ ?>