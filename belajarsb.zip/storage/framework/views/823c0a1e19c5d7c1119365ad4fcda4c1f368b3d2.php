

<?php $__env->startSection('content'); ?>;
<br><br><br><br><br><br><br>
<div class="container mt-4">
    <div class="row justify-content-center mt-4">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">Product</div>
                <img src="<?php echo e(asset('image')); ?>/<?php echo e($food->image); ?>" class="img-responsive" width="353"  alt="">
                
            </div>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Detail</div>
                <div class="card-body">
                    <p><h2><?php echo e($food->name); ?></h2></p>
                    <p class="lead"><?php echo e($food->description); ?></p>
                    <p><h4>Rp.<?php echo e($food->price); ?></h4></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar2\resources\views/detail.blade.php ENDPATH**/ ?>