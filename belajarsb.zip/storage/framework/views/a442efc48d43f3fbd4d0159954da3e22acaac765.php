
<?php $__env->startSection('content'); ?>
<!-- <div style="margin-top:150px ;"></div>
<div class="container">
    <div class="row justify-content-center">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-12">
            <h2 style="color:blue"><?php echo e($category->name); ?></h2>
            <div class="jumbotron">
                <div class="row">
                    <?php $__currentLoopData = App\Models\Food::where('category_id',$category->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <img src="<?php echo e(asset('image')); ?>/<?php echo e($food->image); ?>" width="200" height="155" class="mt-4 mx-4">
                        <p class="text-center"><?php echo e($food->name); ?>

                            <span><?php echo e($food->price); ?></span>
                        </p>
                        <p class="text-center"><a href="<?php echo e(route('detail',[$food->id])); ?>" class="text-decoration-none">
                                <button class="btn btn-outline-danger">
                                    View
                                </button>
                            </a></p>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div> -->







<div class="blog">

    <div class="row">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 col-sm-12 mar_bottom">
            <?php $__currentLoopData = App\Models\Food::where('category_id',$category->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="blog_box">
                <div class="blog_img_box">
                    <figure><img style="height: 250px;" src="<?php echo e(asset('image')); ?>/<?php echo e($food->image); ?>" alt="#" />
                    </figure>
                </div>
                <h3 class="text-danger"><?php echo e($category->name); ?></h3>

                <p class="text-center fw-bold"> <b> <?php echo e($food->name); ?> </b></p>
                <p><span class="theme_color">Rp. </span><?php echo e($food->price); ?></p>
                <p><?php echo e($food->description); ?> </p>
                <p><?php echo e($food->created_at->diffForHumans()); ?></p>
                <p class="text-center"><a href="<?php echo e(route('detail',[$food->id])); ?>" class="text-decoration-none">
                        <button class="btn btn-outline-danger">
                            View
                        </button>
                    </a></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar2\resources\views/index.blade.php ENDPATH**/ ?>