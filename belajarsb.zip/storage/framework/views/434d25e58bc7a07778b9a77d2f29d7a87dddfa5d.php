<!DOCTYPE html>
<html lang="en">

<head>
    <!-- basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
    <title> Yong-Yong Esport</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- bootstrap css -->
    <link rel="stylesheet" href="<?php echo e(asset('/spicyo/css/bootstrap.min.css')); ?>">
    <!-- owl css -->
    <link rel="stylesheet" href="<?php echo e(asset('spicyo/css/owl.carousel.min.css')); ?>">
    <!-- style css -->
    <link rel="stylesheet" href="<?php echo e(asset('spicyo/css/style.css')); ?>">
    <!-- responsive-->
    <link rel="stylesheet" href="<?php echo e(asset('spicyo/css/responsive.css')); ?>">
    <!-- awesome fontfamily -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
</head>
<!-- body -->

<body class="main-layout">
    <!-- loader  -->
    <!-- <div class="loader_bg">
        <div class="loader"><img src="<?php echo e(asset('spicyo/images/loading.gif')); ?>" alt="" /></div>
    </div> -->

    <div class="wrapper">
        <!-- end loader -->

        <div class="sidebar">
            <!-- Sidebar  -->
            <nav id="sidebar">

                <div id="dismiss">
                    <i class="fa fa-arrow-left"></i>
                </div>

                <ul class="list-unstyled components">

                    <li class="active">
                        <a href="index.html">Home</a>
                    </li>
                    <li>
                        <a href="about.html">About</a>
                    </li>
                    <li>
                        <a href="recipe.html">Recipe</a>
                    </li>
                    <li>
                        <a href="blog.html">Blog</a>
                    </li>
                    <li>
                        <a href="contact.html">Contact Us</a>
                    </li>
                </ul>

            </nav>
        </div>

        <div id="content">
            <!-- header -->
            <header>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="full">
                                <a class="logo" href="<?php echo e(('/')); ?>"><img src="<?php echo e(asset('spicyo/images/logoyong.png')); ?>" alt="#" /></a>
                            </div>
                        </div>
                        <div class="col-md-9">
                            <div class="full">
                                <div class="right_header_info">
                                    <ul>
                                        <li class="button_user"><a class="button active" href="<?php echo e('/login'); ?>">Login</a><a class="button" href="<?php echo e('/register'); ?>">Register</a></li>
                                        <li><img style="margin-right: 15px;" src="<?php echo e(asset('spicyo/images/search_icon.png')); ?>" alt="#"></li>
                                        <li>
                                            <button type="button" id="sidebarCollapse">
                                                <img src="<?php echo e(asset('spicyo/images/menu_icon.png')); ?>" alt="#">
                                            </button>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- end header -->
            <?php /**PATH E:\XAMPP\htdocs\belajar2\resources\views/front/layouts/header.blade.php ENDPATH**/ ?>