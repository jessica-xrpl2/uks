

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <?php if(Session::has('message')): ?>
      <div class="alert alert-success">
        <?php echo e(Session::get('message')); ?>

      </div>
      <?php endif; ?>

      <div class="card">
        <div class="card-header">Semua Sarung
          <span class="float-end">
            <a href="<?php echo e(route('sarung.create')); ?>">
              <button class="btn btn-outline-secondary">Tambah Sarung</button>
            </a>
          </span>
        </div>
        <div class="card-body">
          <table class="table table-responsive">
            <thead class="table-dark">
              <tr>
                <th scope="col">Gambar</th>
                <th scope="col">Nama</th>
                <th scope="col">Deskripsi</th>
                <th scope="col">Stok</th>
                <th scope="col">Edit</th>
                <th scope="col">Delete</th>
              </tr>
            </thead>
            <tbody>

              <?php if(count($sarungs)>0): ?>
              <?php $__currentLoopData = $sarungs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$sarung): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>
                <td><img src="<?php echo e(asset('image')); ?>/<?php echo e($sarung->image); ?>" width="100" alt=""></td>
                <td><?php echo e($sarung->name); ?></td>
                <td><?php echo e($sarung->description); ?></td>
                <td><?php echo e($sarung->stok); ?></td>
                
                <td>
                  <a href="<?php echo e(route('sarung.edit', [$sarung->id])); ?>"><button class="btn btn-outline-success">Edit</button>
                  </a>
                </td>

                <td>
                  <!-- Button trigger modal -->
                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal<?php echo e($sarung->id); ?>">
                    Delete
                  </button>

                  <!-- Modal -->
                  <div class="modal fade" id="exampleModal<?php echo e($sarung->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                      <form action="<?php echo e(route('sarung.destroy',[$sarung->id])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('DELETE')); ?>

                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Apakah yakin?</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                            Apakah Kamu Yakin?
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-outline-danger">Ya</button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
              <td>Tidak ada Kategori yang dapat ditampilkan.</td>
              <?php endif; ?>
            </tbody>
          </table>
          <?php echo e($sarungs->links()); ?>

        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\htdocs\belajarsb\resources\views/sarung/index.blade.php ENDPATH**/ ?>