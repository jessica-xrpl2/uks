@include('front.layouts.header')
<div class="container">
    @yield('content')
</div>
@include('front.layouts.footer')