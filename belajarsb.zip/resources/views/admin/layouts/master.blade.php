@include('admin.layouts.sidebar')
@include('admin.layouts.navbar')
<div class="container-fluid">
    @yield('content')
</div>
</div>

@include('admin.layouts.footer') 